<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class GoldenTwothousand20ies extends Theme
{
    // Access plugin events in this class
}
